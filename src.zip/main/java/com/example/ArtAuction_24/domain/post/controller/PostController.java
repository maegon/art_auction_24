package com.example.ArtAuction_24.domain.post.controller;

public class PostController {
}
