package com.example.ArtAuction_24.domain.answer.controller;

public class AnswerController {
}
