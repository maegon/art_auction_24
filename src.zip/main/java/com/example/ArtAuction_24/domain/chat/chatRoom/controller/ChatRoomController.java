package com.example.ArtAuction_24.domain.chat.chatRoom.controller;

public class ChatRoomController {
}
