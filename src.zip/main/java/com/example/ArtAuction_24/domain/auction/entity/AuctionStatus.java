package com.example.ArtAuction_24.domain.auction.entity;

public enum AuctionStatus {
    ACTIVE, CLOSED, CANCELLED
}