package com.example.ArtAuction_24.domain.post.entity;

public enum PostType {
    ARTWORK,
    ARTIST,
    PURCHASE,
    SERVICE,
    DELIVERY,
    RETURN,
    OTHER
}