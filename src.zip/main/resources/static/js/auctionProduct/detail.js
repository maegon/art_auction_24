  $(document).ready(function(){
            $('.auctionProductTarget').okzoom({
                width: 150,
                height: 150,
                scaleWidth: 400,
                round: true,
                background: "#fff",
                // backgroundRepeat: "repeat",
                shadow: "0 0 5px #000",
                border: "1px solid black"
                });
        })