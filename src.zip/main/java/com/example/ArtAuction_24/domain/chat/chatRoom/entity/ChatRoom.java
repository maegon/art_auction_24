package com.example.ArtAuction_24.domain.chat.chatRoom.entity;

public class ChatRoom {
}
