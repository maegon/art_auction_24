package com.example.ArtAuction_24.question.entity;

public enum QuestionType {
    작품및작가,
    구매,
    SERVICE,
    배송,
    반품
}