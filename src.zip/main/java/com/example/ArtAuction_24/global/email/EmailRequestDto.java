package com.example.ArtAuction_24.global.email;

import lombok.*;

@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailRequestDto {
    private String username;
    private String email;

}
