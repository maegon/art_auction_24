package com.example.ArtAuction_24.global.base.initData;

public interface BeforeInitData {
    default void beforeInit() {
    }
}
