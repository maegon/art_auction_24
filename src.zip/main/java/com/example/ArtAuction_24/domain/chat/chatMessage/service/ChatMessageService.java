package com.example.ArtAuction_24.domain.chat.chatMessage.service;

public class ChatMessageService {
}
